<?php

namespace App\Http\Controllers;

use App\Repository\Api\MemberRepositoryInterface;
use Illuminate\Http\Request;

class MemberController extends Controller
{
    protected $memebers;

    public function __construct(MemberRepositoryInterface $memebers)
    {
        $this->memebers = $memebers;
    }


    public function store(Request $request)
    {
      return $this->memebers->store($request);
    }
}
