<?php

namespace App\Repository\Api;

interface MemberRepositoryInterface
{

    public function store($request);

}
