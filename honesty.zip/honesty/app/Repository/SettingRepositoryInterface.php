<?php

namespace App\Repository;

interface SettingRepositoryInterface extends RepositoryInterface
{
    public function getActiveUsers();
}
