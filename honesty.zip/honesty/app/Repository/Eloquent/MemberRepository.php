<?php

namespace App\Repository\Eloquent;

use App\Models\Member;
use App\Repository\Api\MemberRepositoryInterface;
use App\Repository\Api\ResponseApi;
use App\Traits\FirebaseNotification;
use App\Traits\PhotoTrait;
use Illuminate\Contracts\Validation\Rule;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Exception;



class MemberRepository extends ResponseApi implements MemberRepositoryInterface


{
    use PhotoTrait, FirebaseNotification;

    public function store($request) : JsonResponse
   {
       {
       try {
           $validator = Validator::make($request->all(), [
               'type' => 'required|in:male,female',
               'postion' => 'required|in:in,out',
               'image_front' => 'required|image',

               'image_back' => 'required|image',
               'image' => 'required|image',
               'cv' => 'required|image',

               'name' => 'required|string',
               'national_ID' => 'required|digits:14|numeric|unique:members,national_ID',
               'card_Date' => 'required',

               'governorate' => 'required',
               'address' => 'required|string',
               'work_place' => 'required|string',

               'partisan' => 'required|string',
               'job' => 'required|string',
               'qualification' => 'required|string',

               'phone' => 'required|digits:11|numeric|unique:members,phone',
               'country' => 'required_if:postion,out',
               'Place_abroad' => 'required_if:postion,out',

               'Passport_number' => [
                   'required_if:postion,out',
                   'nullable',
                   function ($attribute, $value, $fail) use ($request) {
                       if ($request->input('postion') === 'out' && $value !== null) {
                           $exists = DB::table('members')
                               ->where('Passport_number', $value)
                               ->where('postion', 'out')
                               ->exists();

                           if ($exists) {
                               $fail('The passport number has already been taken.');
                           }
                       }
                   },
               ],

               ]);

           if ($validator->fails()) {
               return self::returnDataFail(null, $validator->errors()->first(), 422);
           }

           $member = new Member();
           $member->type=$request->type;
           $member->postion=$request->postion;

           $member->image_front=$request->image_front;
           $member->image=$request->image;
           $member->cv=$request->cv;

           $member->image_back=$request->image_back;
           $member->name=$request->name;
           $member->national_ID=$request->national_ID;

           $member->card_Date=$request->card_Date;
           $member->governorate=$request->governorate;
           $member->address=$request->address;

           $member->work_place=$request->work_place;
           $member->partisan=$request->partisan;
           $member->country=$request->country ?: null;

           $member->Place_abroad=$request->Place_abroad ?: null;
           $member->Passport_number=$request->Passport_number ?: null;
           $member->job=$request->job;

           $member->qualification=$request->qualification;
           $member->phone=$request->phone;
           $member->save();


           return self::returnDataSuccess($member, ' member store success');


       } catch (Exception $exception) {
           return self::returnDataFail(null, $exception->getMessage(), 500);
       }
   } // end storeMember ==> amo matter

   }


}
